package com.mycompany.cinecolombia;

public class CineColombia {

    public static void main(String[] args) {
       

    }
}