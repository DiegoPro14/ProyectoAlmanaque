
package com.mycompany.cinecolombia;

public class Cine {
    private Pelicula pelicula;
    private double precioEntrada;
    private Asiento[][] asientos;

    public Cine(Pelicula pelicula, double precioEntrada, int filas, int columnas) {
        this.pelicula = pelicula;
        this.precioEntrada = precioEntrada;
        this.asientos = new Asiento[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                this.asientos[i][j] = new Asiento((char) (j + 65), i);
            }
        }
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public double getPrecioEntrada() {
        return precioEntrada;
    }

    public Asiento[][] getAsientos() {
        return asientos;
    }

    public boolean sentarEspectador(Espectador espectador) {
        Asiento asientoLibre = buscarAsientoLibre();
        if (asientoLibre != null) {
            asientoLibre.setOcupado(true);
            asientoLibre.setEspectador(espectador);
            return true;
        } else {
            return false;
        }
    }

    private Asiento buscarAsientoLibre() {
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                if (!asientos[i][j].isOcupado()) {
                    return asientos[i][j];
                }
            }
        }
        return null;
    }
}    
    

    
    

   
