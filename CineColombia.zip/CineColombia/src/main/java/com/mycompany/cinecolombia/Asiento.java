
package com.mycompany.cinecolombia;

public class Asiento {
    private char fila;
    private int columna;
    private boolean ocupado;
    private Espectador espectador;

    public Asiento(char fila, int columna) {
        this.fila = fila;
        this.columna = columna;
        this.ocupado = false;
    }

    public char getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public boolean isOcupado() {
        return ocupado;
    }

    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }

    public Espectador getEspectador() {
        return espectador;
    }

    public void setEspectador(Espectador espectador) {
        this.espectador = espectador;
    }
} 
   
